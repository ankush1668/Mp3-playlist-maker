/*Mp3 finder
Author->Shivam Choudhary
License->MIT*/
#include<iostream>
#include<dirent.h>     
#include<string>
#include<algorithm>
#include<string.h>
#include<vector>    
using namespace std;
class mp3file{
    private:
    string f_name;
    string f_path;
    public:
    string showFile(){
        return f_name;
    }
    string showPath(){
        return f_path;
    } 
    mp3file(string filename,string path){
        f_name=filename;       
        f_path=path;
        
    }   
};
vector<string> list;
class dirfile{
    public:
    DIR *dir;           
    struct dirent *ent;
    dirfile(string s){
        dir=opendir(s.c_str());
    }
    bool isDir(){
        if(ent->d_type==4)
            return true;
        else 
            return false;
    }
    bool isMp3(){
        if(ent->d_type==8){
            string temp;
            for(int i=strlen(ent->d_name)-4;i<strlen(ent->d_name);i++)
                temp.push_back(ent->d_name[i]);
            if(temp==".mp3")
                return true;
            else
                return false;
        }
        else
            return false;                   
        }   
};
void mp3find(string s){
    dirfile d(s);
    if(d.dir!=NULL){
        while((d.ent=readdir(d.dir))!=NULL){
            //skips the entities names '.','..' and '.*'
            if(strcmp(d.ent->d_name,".")==0 || strcmp(d.ent->d_name,"..")==0 || d.ent->d_name[0]=='.')
                continue;
            //checks for directory
            if(d.isDir()){
                string temp(d.ent->d_name);
                temp=s+"/"+temp; 
                mp3find(temp);
            }
            //checks for mp3 file
            if(d.isMp3()){
                mp3file m((string)d.ent->d_name,s);
                
                list.push_back((string)d.ent->d_name);                                      
            }    
        }
        closedir(d.dir);
    }
    else
        cout<<"Couldn't open the directory "<<s<<endl;
}
void GetPlaylist(vector<string> list){
    char str,str1;
    str=list[0][0];
    cout<<"Files starts with "<<str<<endl;
    cout<<list[0][0];
    for(int i=1;i<list.size();i++){
str1=list[i][0];
if(str==str1){cout<<list[i]<<endl; continue;}
else {
    cout<<"Files starts with "<<str1<<endl;
    cout<<list[i]<<endl;
    str=str1;
    }
}
}
int main(){
    string inputPath;
    cout<<"Enter the path...."<<endl;
    cin>>inputPath;
    mp3find(inputPath);
    sort(list.begin(),list.end());
    Get(list);
return 0;
}
//End of the program.